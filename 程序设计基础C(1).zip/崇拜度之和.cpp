#include <iostream>
#include <cmath>
using namespace std;
int grade(int *a,int *b)
{
	int sum=0;
	for(int i=0;i<6;i++)
	{
		sum+=a[b[i]-1];
	}
	return sum;
}
int main()
{
	int n;
	cin>>n;
	int *a=new int [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	int K;
	cin>>K;
	int *b=new int [6];
	for(int i=0;i<K;i++)
	{
		for(int j=0;j<6;j++)
		{
			cin>>b[j];
		} 
		cout<<grade(a,b)<<endl;
	}
	delete []a;
	delete []b;
}
