//�ڶ�С������ 
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a,n;
	int zx,b=100;
	cin>>n;
	cin>>a;
	zx=a;
	for(int i=2;i<=n;i++)
	{
		cin>>a;
		if(a<zx)
		{
			b=zx;
			zx=a;
		}
		else if(a<b)
		{
			b=a;
		}
	}
	cout<<b;
}


//�������λ�� 
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[10000],n;
	int zd=0,pos=0;
	cin>>n;
	cin>>a[1];
	zd=a[1],pos=1;
	for(int i=2;i<=n;i++)
	{
		cin>>a[i];
		if(a[i]>zd)
		{
			zd=a[i];
			pos=i;
		}
	} 
	cout<<pos;
}


#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a,n;
	int zd=0,pos=0;
	cin>>n;
	cin>>a;
	zd=a;
	pos=1;
	for(int i=2;i<=n;i++)
	{
		cin>>a;
		if(a>zd)
		{
			zd=a;
			pos=i;
		}
	}
	cout<<pos;
}


//����ƽ��ֵ���� 
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[30],n,s=0;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		s+=a[i];
	}
	double av=s*1.0/n;
	for(int i=0;i<n;i++)
	{
		if(a[i]>av)
		{
			cout<<a[i]<<endl;
		}
	}
}


//���ת 
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int b[n];
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
	}
	for(int i=n-1;i>=0;i--)
	{
		cout<<b[i]<<" ";
	}
}


/*#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int b[n];
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
	}
	for(int i=0,j=n-1-i;i<j;i++,j--)
	{
		int t=b[i];
		b[i]=b[j];
		b[j]=t;
	}
	cout<<b[n]<<" ";
}*/


//��ָ������Ų�����
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n,x,num=0;
	cin>>n;
	int b[100];
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
	}
	cin>>x;
	for(int i=0;i<n;i++)
	{
		if(b[i]!=x)
		{
			cout<<b[i]<<" ";
		}
		else
		{
			num++;
		}
	}
	for(int i=0;i<num;i++)
	{
		cout<<x<<" ";
	}
}


#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n,x;
	cin>>n;
	int b[100];
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
	}
	cin>>x;
	int sum=0;
	for(int i=0;i<n-sum;i++)
	{
		if(b[i]==x)
		{
			for(int j=i+1;j<n;j++)
			{
				b[j-1]=b[j];
			}
			b[n-1]=x;
			sum++;
			i--;
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<b[i]<<" ";
	}
}

//�����������м�
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[100],n;
	int zd=0,pos=0;
	cin>>n;
	cin>>a[0];
	zd=a[0];
	for(int i=1;i<n;i++)
	{
		cin>>a[i];
		if(a[i]>zd)
		{
			zd=a[i];
			pos=i;
		}
	} 
	a[pos]=a[(n+1)/2-1];
	a[(n+1)/2-1]=zd;
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}
}



//���������ֵ�λ��
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[30];
	int n,t;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>t;
	for(int i=n;i>=1;i--)
	{
		if(a[i]==t)
		{
			cout<<i;
			return 0;
		}
	}
	cout<<-1;
}


#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[100];
	int n,t,ans;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>t;
	for(int i=1;i<=n;i++)
	{
		if(a[i]==t)
		{
			ans=i;
		}
	}
	cout<<(ans==0?-1:ans);
}


#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[100];
	int n,t,ans=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>t;
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=t)
		{
			continue;
		}
		else
		{
			ans=i;
		}
	}
	cout<<(ans==0?-1:ans);
}


//�Ʋ���������
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[50]={0,1};
	int n;
	cin>>n;
	for(int i=2;i<=n;i++)
	{
		a[i]=a[i-1]+a[i-2];
	}
	cout<<a[n];
}


//���ֵ
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[100];
	int n,zd=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(a[i]+a[j]>zd)
			{
				zd=a[i]+a[j];
			}
		}
	}
	cout<<zd;
}
