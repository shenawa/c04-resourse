#include <iostream>
using namespace std;
int main()
{
	char str[80],substr[80];
	int i,j,k,num=0;
	gets(str);
	gets(substr);
	for(i=0;str[i]!='\0';i++)
	{
		for(j=i,k=0;substr[k]==str[j];k++,j++)
		{
			if(substr[k+1]=='\0')
			{
				num++;
				break;
			}
		}
	}
	cout<<num<<endl;
 } 
