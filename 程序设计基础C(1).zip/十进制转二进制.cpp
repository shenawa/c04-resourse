#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
void digui(long long n)
{
	if(n<2)
	{
		cout<<n;
		return;
	}
	digui(n/2);
	cout<<n%2;
}
int main()
{
	long long m;
	cin>>m;
	if(m==0)
	{
		cout<<0;
	}
	else
	{
		digui(m);
	}
}
