#include <iostream>
using namespace std;
void maxvalue(int *s, int n, int *pmax)
{
	int i;
	*pmax=*s;
	for(i=1;i<n;i++)
		if(*(s+i)>*pmax)
		*pmax=*(s+i);
}
int main()
{
    int n,*a,maxv;
	cin>>n;
	a=new int [n];
	for(int i=0;i<n;i++) 
		cin>>a[i]; 
	maxvalue(a,n,&maxv);
	cout<<maxv;
	delete [] a;
	return 0;
}
