//ö���������������еĹ����� 
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	int c=min(a,b);
	for(int i=1;i<=c;i++)
	{
		if(a%i==0 and b%i==0)
		{
			
			cout<<i<<" ";
		}
	}
}



//�����滻
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int n,sum=0;
	cin>>n;
	int b[1000];
	for(int i=0;i<n;i++)
	{
		cin>>b[i]; 
	}
	for(int i=0;i<n;i++)
	{
		sum+=b[i];
	}
	double avg=sum/n;
	int max=b[0],min=b[0];
	for(int i=1;i<=n;i++)
	{
		if(b[i]>max)
		{
			max=b[i];
		}
		if(b[i]<min)
		{
			min=b[i];
		}
	}
	for(int i=0;i<n;i++)
	{
		if(b[i]>avg)
		{
			b[i]=max;
		}
		else
		{
			b[i]=min;
		}
		cout<<b[i]<<" ";
	}
}



//���ظ�
#include <iostream>
#include <cstdio>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[100];
	int b[101]={0};
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		b[a[i]]++;
	}
	for(int i=0;i<=100;i++)
	{
		if(b[i]==2)
		{
			cout<<i;
		}
	}
}

#include <iostream>
#include <cstdio>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int a[101]={0},b;
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>b;
		a[b]++;
		if(a[b]>1)
		{
			cout<<b;
		}
	}
}



//��n�����г��ִ���������
#include <iostream>
#include <cstdio>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n,zd=0,s;
	cin>>n;
	int a[100];
	int b[101]={0};
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		b[a[i]]++;
	}
	for(int i=0;i<=100;i++)
	{
		if(b[i]>zd)
		{
			zd=b[i];
			s=i;
		}
	}
	cout<<s;
}

#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int a[101]={0},b,zd=0,ans;
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>b;
		a[b]++;
		if(a[b]>zd)
		{
			zd=a[b];
			ans=b;
		}
	}
	cout<<ans;
}



//�ҿ���
#include <iostream>
#include <cstdio>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n,a,zd=0,s;
	cin>>n;
	int b[1001]={0};
	for(int i=1;i<=n;i++)
	{
		cin>>a;
		b[a]++;
	}
	for(int i=1;i<=1000;i++)
	{
		if(b[i]%2)
		{
			cout<<i;
			break;
		}
	}
}




//�������� 
#include <iostream>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    int a[1000]; 
    for (int i=0;i<n;++i)
	{
        cin>>a[i];
    }
    int sum=0;
    while(1) 
	{
        int s=0;
        for(int i=0;i<n;++i) 
		{
            if(a[i]!=0) 
			{
                s=1;
                break;
            }
        }
        if(s==0) 
		{
            break;
        }
        int max=-1;
        int maxpos=-1;
        for(int i=0;i<n;++i) 
		{
            if(a[i]>max) 
			{
                max=a[i];
                maxpos=i;
            }
        }
        int min=2147483647;
        int minpos=-1;
        for (int i=0;i<n;++i) 
		{
            if (a[i]!=0 && a[i]<min) 
			{
                min=a[i];
                minpos=i;
            }
        }
        a[maxpos]-=a[minpos];
        sum++;
    }
    cout<<sum;
}
