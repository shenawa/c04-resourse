//������ȷ���루�迼�ǵ�ÿ�п��ܲ�ֹһ�����ֵ�� 
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	int s[a][b];
	int sum=0;
	for(int i=0;i<a;i++)
	{
		for(int j=0;j<b;j++)
		{
			cin>>s[i][j];
		}
	}
	for(int i=0;i<a;i++)
	{
		int max=s[i][0];
		for(int j=1;j<b;j++)
		{
			if(max<s[i][j])
			{
				max=s[i][j];			
			}
		}
		for(int y=0;y<b;y++)
		{
			if(s[i][y]==max)
			{
				int min=s[0][y];
				for(int x=1;x<a;x++)
		        {
			        if(min>s[x][y])
			        {
				        min=s[x][y];
			        }
		        }
		        if(max==min)
		        {
		        	sum++;
				}
			}
		}
	}
	if(sum>0)
	{
		cout<<"Yes";
	}
	else
	{
		cout<<"No";
	}
	return 0;
}




/*#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	int s[101][101];
	for(int i=0;i<a;i++)
	{
		for(int j=0;j<b;j++)
		{
			cin>>s[i][j];
		}
	}
	int min[101];
	for(int j=0;j<b;j++)
	{
		min[j]=s[0][j];
		for(int i=1;i<a;i++)
		{
			if(min[j]>s[i][j])
			{
				min[j]=s[i][j];
			}
		}
	}
	int max[101];
	for(int i=0;i<a;i++)
	{
		max[i]=s[i][0];
		for(int j=1;j<b;j++)
		{
			if(max[i]<s[i][j])
			{
				max[i]=s[i][j];			
			}
		}
	}
	bool k=false;
	for(int i=0;i<a;i++)
	{
		for(int j=0;j<b;j++)
		{
			if()
			if(s[i][j]==max[i] && s[i][j]==min[j])
			{
				k=true;
				break;
			}
		}
		if(k)
		{
			break;
		}
	}
	if(k=true)
	{
		cout<<"Yes";
	}
	else
	{
		cout<<"No";
	}
	return 0;
}
*/

/*
#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	int s[101][101];
	for(int i=0;i<a;i++)
	{
		for(int j=0;j<b;j++)
		{
			cin>>s[i][j];
		}
	}
	int min[101];
	for(int j=0;j<b;j++)
	{
		min[j]=s[0][j];
		for(int i=1;i<a;i++)
		{
			if(min[j]>s[i][j])
			{
				min[j]=s[i][j];
			}
		}
	}
	bool x=false;
	int max[101];
	for(int i=0;i<a;i++)
	{
		max[i]=s[i][0];
		for(int j=1;j<b;j++)
		{
			if(max[i]<s[i][j])
			{
				max[i]=s[i][j];			
			}
		}
		for(int j=0;j<b;j++)
		{
			if(s[i][j]==max[i])
			{
				if(s[i][j]==min[j])
				x=true;
				break;
			}
		}
	}
	if(x=true)
	{
		cout<<"Yes";
	}
	else
	{
		cout<<"No";
	}
	return 0;
}
*/
