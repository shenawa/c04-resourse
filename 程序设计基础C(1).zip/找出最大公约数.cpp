#include <iostream>
#include <cmath>
using namespace std;
int gcd(int a,int b)
{
	if(b==0) return a;
	return gcd(b,a%b);
}
void change(int* a,int n)
{
	for(int i=0;i<n;i++)
	{
		int t=i;
		for(int j=i+1;j<n;j++)
		{
			if(a[j]<a[t])
			{
				t=j;
			}
		}
		swap(a[i],a[t]);
	}
}
int main()
{
	int n;
	cin>>n;
	int* a=new int [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	change(a,n);
	int zx=a[0];
	for(int i=2;i<n;i++)
	{
		a[1]=gcd(a[1],a[i]);
	}
	if(a[1]==zx)
	{
		cout<<"Yes";
	}
	else
	{
		cout<<"No";
	}
	return 0;
}
