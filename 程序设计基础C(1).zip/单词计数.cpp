#include<iostream>
using namespace std;
int main()
{
	char a[505];
	gets(a);
	int ans=0;
	bool word=false;
	for(int i=0;a[i]!='\0';i++)
	{
		if(a[i]==' '||a[i]=='\n'||a[i]=='\t')
		{
			word=false;
		}
		else if(word==false)
		{
			word=true;
			ans++;
		}
	}
	cout<<ans;
}
