#include <iostream>
using namespace std;
int main() {
    int n;
    cin >> n;
    int a[1000]; 
    for (int i=0;i<n;++i)
	{
        cin>>a[i];
    }
    int sum=0;
    while(1) 
	{
        int s=0;
        for(int i=0;i<n;++i) 
		{
            if(a[i]!=0) 
			{
                s=1;
                break;
            }
        }
        if(s==0) 
		{
            break;
        }
        int max=-1;
        int maxpos=-1;
        for(int i=0;i<n;++i) 
		{
            if(a[i]>max) 
			{
                max=a[i];
                maxpos=i;
            }
        }
        int min=2147483647;
        int minpos=-1;
        for (int i=0;i<n;++i) 
		{
            if (a[i]!=0 && a[i]<min) 
			{
                min=a[i];
                minpos=i;
            }
        }
        a[maxpos]-=a[minpos];
        sum++;
    }
    cout<<sum;
}
