#include <iostream>
#include <iomanip>
using namesapce std;
int main()
{
	int a,b;
	cin>>a>>b;
	int fz=a+b;
	int fm=a*b;
	int ans;
	for(int i=1;i<=fz;i++)
	{
		if(fz%i==0 and fm%i==0) ans=i;
	}
	cout<<fz/ans<<"/"<<fm/ans;
}
