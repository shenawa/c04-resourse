// ɸ��������
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[161]={1,1,0}; 
	for(int i=2;i*i<=n;i++)
	{
		if(a[i]==0)
		{
			for(int j=i*2;j<=n;j+=i)
			{
				a[j]=1; 
			}
		}
	}
	for(int i=2;i<=n;i++)
	{
		if(a[i]==0)
		{
			cout<<i<<endl;
		}
	}
	
}



//���ǲ�������
#include <iostream>
#include <cmath>
using namespace std;
bool issh(int p)
{
	if(p<=1)    return false;
	if(p<4)     return true;
	if(p%2==0)  return false;
	for(int i=3;i<=sqrt(p);i+=2)
	{
		if(p%i==0)
		{
			return false;
		}
	}
	return true; 
}
int main()
{
	int n,a;
	int zx,cx;
	cin>>a;
	zx=cx=a;
	while(cin>>n)
	{
		if(n<zx)
		{
			cx=zx;
			zx=n;
		}
		else if(n<cx) 
		{
			cx=n;
		}
	}
	if(issh(cx-zx))
	{
		cout<<"Yes";
	}
	else
	{
		cout<<"No\"o";
	}
	return 0;
}







//Ѱ�������� 
#include <iostream>
#include <cmath>
using namespace std;
bool issh(int p)
{
	if(p<=1)    return false;
	if(p<4)     return true;
	if(p%2==0)  return false;
	for(int i=3;i<=sqrt(p);i+=2)
	{
		if(p%i==0)
		{
			return false;
		}
	}
	return true; 
}
int main()
{
	int n;
	while(cin>>n&&n)
	{
		for(int i=n/2;i>=2;i--)
		{
			if(issh(i) && issh(n-i))
			{
				cout<<i<<" "<<n-i<<endl;
				break; 
			}
		}
	}
	return 0;
}



//���2~n�������к���5������
#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cin>>n;
	for(int i=2;i<=n;i++)
	{
		int a=i,flag=0; 
		while(a>0)
		{
			if(a%10==5)
			{
				flag=1;
				break;
			}
			a/=10;
		}
		int b=i,yz=0;
		for(int j=1;j<=i;j++)
		{
			if(b%j==0)
			{
				yz++;
			}
		}
		if(flag==1 && yz==2)
		{
			cout<<i<<endl;
		}
	}
}



//��������
#include <iostream>
#include <cmath>
using namespace std;
int main() 
{
	int c,d,sum=0;
	cin>>c>>d;
	long long a[1000];
	for(int i=0;i<d;i++)
	{
		a[i]=1;
	}
	a[0]=0;
	a[1]=0;
	for(int i=2;i*i<d;i++)
	{
		if(a[i]==1)
		{
			for(int j=i*i;j<d;j+=i)
			{
				a[j]=0;
			}
		}
	}
	for(int i=c;i<d;i++)
	{
		if(a[i]==1)
		{
			sum++;
		}
	}
	cout<<sum;
}


#include <iostream>
#include <cmath>
using namespace std;
int main() 
{
	int a,b,sum=0;
	cin>>a>>b;
	int c[1001]={0};
	for(int i=0;i<=b;i++)
	{
		c[i]=1;
	}
	c[0]=0;
	c[1]=0;
	int sqrtb=sqrt(b);
	for(int i=2;i<=sqrtb;++i)
	{
		if(c[i]==1)
		{
			for(int j=i*i;j<=b;j+=i)
			{
				c[j]=0;
			}
		}
	}
	for(int i=a;i<=b;++i)
	{
		if(c[i]==1)
		{
			sum++;
		}
	}
	cout<<sum;
}
