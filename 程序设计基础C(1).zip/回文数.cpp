//�жϻ�����
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[100],t=0;
	while(n>0)
	{
		a[t++]=n%10;
		n/=10;
	}
	for(int i=0,j=t-1;i<j;i++,j--)
	{
		if(a[i]!=a[j])
		{
			cout<<"No";
		}
		else
		{
			cout<<"Yes";
		}
	}
	return 0;
}



//��С�Ļ�����
#include <iostream>
#include <cmath>
using namespace std;
bool hws(long m)
{
	int a[100],t=0;
	while(m>0)
	{
		a[t++]=m%10;
		m/=10;
	}
	for(int i=0,j=t-1;i<j;i++,j--)
	{
		if(a[i]!=a[j])
		{
			return false;
		}
	}
	return true;
} 
int main()
{
	long n;
	while(cin>>0)
	{
		for(int i=n+1;;i++)
		{
			if(hws(i))
			{
				cout<<i<<endl;
				break;
			}
		}
	}
}



//˫�ػ�����
#include <iostream>
#include <cmath>
using namespace std;
bool doublehws(long m,long s)
{
	int a[100],t=0;
	while(m>0)
	{
		a[t++]=m%s;
		m/=s;
	}
	for(int i=0,j=t-1;i<j;i++,j--)
	{
		if(a[i]!=a[j])
		{
			return false;
		}
	}
	return true;
} 
int main()
{
	for(int i=1;i<=1000;i++)
	{
		if(doublehws(i,10) && doublehws(i,2))
		{
			cout<<i<<"Ϊ˫�ػ�����"<<endl; 
		}
	}
}
