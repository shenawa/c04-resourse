#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	long long n;
	cin>>n;
	if(n==0)
	{
		cout<<1<<endl<<0<<endl;
		return 0;
	}
	int sum=0;
	long long s=n;
	while(s!=0)
	{
		s/=10;
		sum++;
	}
	cout<<sum<<endl;
	long long t=1;
	for(int i=1;i<sum;i++)
	{
		t*=10;
	}
	while(t>0)
	{
		int m=n/t;
		cout<<m<<endl;
		n%=t;
		t/=10;
	}
	return 0;
}

