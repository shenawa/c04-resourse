#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int n,ans=1;
	cin>>n;
	bool k=false;
	for(int i=0;i<n;i++)
	{
		a[i]=new int [n];
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cin>>a[i][j];
		}
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
			if(a[i][j]==0)
			{
				k=true;
				break;
			}
		}
	}
	if(k=true)
	{
		cout<<"yes"<<endl;
		for(int i=0;i<n;i++)
	    {
		    for(int j=0;j<n;j++)
		    {
		    	
			    if(i==j)
			    {
			    	
				    ans*=a[i][j];
			    }
		    }
	    }
	    cout<<ans;
	}
	else
	{
		cout<<"no"<<endl;
	}
}


#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int n,s=1;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		for(int j=0;i<n;j++)
		{
			scanf("%d",&a[i][j]);
			if(i==j) s*=a[i][j];
			if(i>j and a[i][j]!=0)
			{
				cout<<"no"<<endl;
				return 0;
			}
		}
	}
	cout<<"yes\n"<<s;
	for(int i=0;i<n;i++)
	{
		delete [] a[i];
	}
	delete [] a;
	a=NULL;
}



#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int n;
	int s=1;
	cin>>n;
	int a[n][n];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cin>>a[i][j];
			if(i==j) s*=a[i][j];
			if(i>j and a[i][j]!=0)
			{
				cout<<"no";
				return 0;
			} 
		}
	}
	cout<<"yes"<<endl<<s;
}
