#include <iostream>
using namespace std;
int szh(int n,int k)
{
	int sum=0;
	while(n>0)
	{
		if(n%10==k) sum++;
		n/=10;
	}
	return sum;
}
int main()
{
	int n,k,ans=0;
	cin>>n>>k;
	for(int i=0;i<n;i++)
	{
		ans+=szh(i,k);
	}
	cout<<ans;
	return 0;
}


#include <iostream>
using namespace std;
void szh(int a,int k,int *s)
{
	*s=0;
	while(a>0)
	{
		if(a%10==k) (*s)++;
		a/=10;
	}
} 
int main()
{
	int n,k,sum=0,s;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		szh(i,k,&s);
		sum+=s;
	 } 
	cout<<sum;
	return 0;
}
