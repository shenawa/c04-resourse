#include<iostream>
using namespace std;
int gcd(int a,int b)
{
	if(b==0) return a;
	return gcd(b,a%b);
}
int gbs(int m,int n)
{
	int ans;
	ans=m*n/gcd(m,n);
	return ans;
}
struct sb
{
	int num;
	int count; 
};
void mySwap(sb *p1, sb *p2)
{
	sb t;
	t=*p1;
	*p1=*p2;
	*p2=t;
}
int main()
{
	int n;
	cin>>n;
	int* a=new int [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	int ans=a[0];
	for(int i=1;i<n;i++)
	{
		ans=gbs(ans,a[i]);
	} 
	cout<<ans<<endl;
	int t[10000]={0};
	int temp=ans;
	for(int i=2;i<=temp;i++)
	{
		while(temp%i==0)
		{
			t[i]++;
			temp/=i;
		}
	} 
	sb tc[100001]={0};
	int cnt=0;
	for(int i=2;i<=ans;i++)
	{
		if(t[i]>0)
		{
			tc[cnt].num =i;
			tc[cnt].count =t[i];
			cnt++;
		}
	}
	for(int i=0;i<cnt-1;++i)
	{
		for(int j=0;j<cnt-i-1;++j)
		{
			if(tc[j].count<tc[j+1].count || (tc[j].count==tc[j+1].count&&tc[j].num<tc[j+1].num))
			{
				mySwap(tc+j,tc+j+1);
			}
		}
	}
	cout<<tc[0].num<<": "<<tc[0].count ; 
	for(int i=1;i<cnt;i++)
	{	
		cout<<", "<<tc[i].num<<": "<<tc[i].count;
	}
	delete [] a;
	return 0;
}





#include <iostream>
#include <cstdio>
using namespace std;
struct tj
{
	int zys;
	int gs;
};
int gys(int a,int b)
{
	if(b==0) return a;
	return gys(b,a%b);
}
int main()
{
	int n,a,b;
	cin>>n;
	cin>>a;
	int s=a;
	for(int i=2;i<=n;i++)
	{
		cin>>b;
		s=s*b/gys(s,b);
	}
	cout<<s<<endl;
	int gbs=s,k=2;
	int count[100001]={0};
	while(gbs!=1)
	{
		while(gbs%k==0)
		{
			gbs/=k;
			count[k]++;
		}
		k++;
	}
	tj ans[100001]={0};
	int len = 0;
	for(int i=2;i<=100000;i++)
	{
		if(count[i]!=0)
		{
			ans[len].zys=i;
			ans[len].gs=count[i];
			len++;
		}
	}
	for(int i=0;i<len-1;i++)
	{
		for(int j=0;j<len-i-1;j++)
		{
			if(ans[j].gs<ans[j+1].gs
			or (ans[j].gs==ans[j+1].gs and ans[j].zys<ans[j+1].zys))
			{
				tj temp = ans[j];
				ans[j] = ans[j+1];
				ans[j+1] = temp;
			}
		}
	}
	bool first = true;
	for(int i=0;i<len;i++)
	{
		if(!first)
			cout<<", "; 
		cout<<ans[i].zys<<": "<<ans[i].gs;
		first = false;
	}
	return 0;
}
