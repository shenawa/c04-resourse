#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
int gcd(int a,int b)
{
	if(b==0) return a;
	return gcd(b,a%b);
}
int jzzh(char* a)
{
	int len=strlen(a);
	int fz=0;
	for(int i=2;i<len;i++)
	{
		fz=fz*10+a[i]-'0';
	}
	return fz;
}
int main()
{
	char a[15];
	cin>>a;
	int len=strlen(a)-2;
	int fz=jzzh(a);
	int fm=pow(10,len);
	int t=gcd(fz,fm);
	cout<<fz/t<<"/"<<fm/t;
}
