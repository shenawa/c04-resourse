#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n,m;
	cin>>n>>m;
	int**a=new int* [n];
	for(int i=0;i<n;i++)
	{
		a[i]=new int [m];
		char c;
		for(int j=0;j<m;j++)
		{
			cin>>c;
			a[i][j]=c-'0';
		}
	}
	int ans=0;
	for(int s=0;s<n;s++)
	{
		for(int x=0;x<m;x++)
		{
			for(int z=s;z<n;z++)
			{
				for(int y=x;y<m;y++)
				{
					int shu1=0,shu2=0;
					for(int i=s;i<=z;i++)
					{
						for(int j=x;j<=y;j++)
						{
							if(a[i][j]==0) shu1++;
							else shu2++;
						}
					}
					if(shu1==shu2)
					{
						int num=(z-s+1)*(y-x+1);
						if(num>ans) ans=num;
					}
				}
			}
		}
	}
	cout<<ans<<endl;
	for(int i=0;i<n;i++)
	{
		delete [] a[i];
	}
	delete [] a;
	return 0;
}
