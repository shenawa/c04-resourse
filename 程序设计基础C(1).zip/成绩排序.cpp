#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
struct stu
{
	char name[20];
	double fs;
};
int main()
{
	int n;
	cin>>n;
	stu a[105];
	for(int i=0;i<n;i++)
	{
		cin>>a[i].name >>a[i].fs ;
	}
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(a[i].fs <a[j].fs )
			{
				double t=a[i].fs ;
				a[i].fs =a[j].fs ;
				a[j].fs =t;
				char t_name[20];
				strcpy(t_name,a[i].name );
				strcpy(a[i].name ,a[j].name );
				strcpy(a[j].name ,t_name);
			}
		}
	}
	for(int i=0;i<8;i++)
	{
		cout<<a[i].name <<" "<<a[i].fs <<endl;
	}
}
