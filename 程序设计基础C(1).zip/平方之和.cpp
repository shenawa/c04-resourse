#include <iostream>
#include <cmath>
using namespace std;
bool exist(int n)
{
	for(int i=1;i<=sqrt(n);i++)
	{
		for(int j=1;j<=sqrt(n);j++)
		{
			if(i*i+j*j==n) return true;
		}
	}
	return false;
}
int main()
{
	int n;
	cin>>n; 
	int* a=new int [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		if(exist(a[i])) cout<<"Yes"<<endl;
		else cout<<"No"<<endl;
	}
	delete [] a;
	a=NULL;
}
