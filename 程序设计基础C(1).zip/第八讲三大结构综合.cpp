//С��� 
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{
	int N,M;
	cin>>N;
	cin>>M;
	for(int i=1;i<=N;i++)
	{
		if(i%M==0)
		{
			continue;
		}
		else
		cout<<i<<endl; 
	}
}

//���ֵ����Сֵ�Ĳ�
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int M,num;
	cin>>M;
	cin>>num;
	int max=num;
	int min=num;
	int i=1;
	while(i<M)
	{
		cin>>num;
		if(num>max) max=num;
		if(num<min) min=num;
		i++;
	}
	cout<<max-min<<endl;
	return 0;
}

//����0�ͽ���
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a,b,sum=0,res=0;
	char c;
	while(cin>>a>>c>>b)
	{
		if(c=='+')
		res=a+b;
		if(c=='-')
		res=a-b;
		if(res!=0)
		{
			sum++;
		}
		else
		{
			break;
		}
	}
	cout<<sum+1<<endl;
}



//�ֶκ���
#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	double x,y;
	cin>>x;
	if(x<0)
	{
		y=fabs(x);
	}
	else if(x<3)
	{
		y=sqrt(x*x*x+1)/(x*x);
	}
	else if(x<7)
	{
		y=exp(x)*sin(x*3.1415926535/180)+pow(x,0.2);
	}
	else
	{
		y=(5*x+6)*log(x);
	}
	cout<<fixed<<septrecision(2)<<y<<endl;
}

//������
#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int n;
	while(cin>>n)
	{
		if(n<1 or n>9)
		{
			continue;
		}
		long long s=0,sum=0;
		for(int i=1;i<=n;i++)
		{
			s=s*10+n;
			sum+=s;
		}
		cout<<sum<<endl;
	}
	cout<<endl;
} 



//��⼶����ʽ
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	double x,S=0;
	double term=1;
	int n=1;
	cin>>x;
	while(fabs(term)>=1e-5)
	{
		S=S+term;
		term=-term*x*x/(2*n*(2*n-1));
		n++
	}
	cout<<"S="<<S<<endl;
	return 0;
}
