#include <iostream>
#include <cstring>
using namespace std;
int main()
{
	int n,maxv=0;
	cin>>n;
	int* a=new int [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		maxv=max(maxv,a[i]);
	}
	if(maxv<171) cout<<-1;
	else
	{
		int f=true,k=0;
		for(int i=0;i<n;i++)
		{
			if(a[i]>170)
			{
				if(a[i]<=a[k]||f)
				{
					k=i;
					f=false;
				}
			}
		}
		cout<<k<<" "<<a[k];
	}
	delete [] a;
	a=NULL;
} 
