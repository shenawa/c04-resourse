#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int h,l;
	cin>>h>>l;
	int a[101][101];
	for(int i=0;i<h;i++)
	{
		for(int j=0;j<l;j++)
		{
			cin>>a[i][j];
		}
	}
	for(int i=0;i<l;i++)
	{
		for(int j=0;j<h;j++)
		{
			
			cout<<a[h-1-j][i]<<" ";
		}
		cout<<"\n";
	}
}
