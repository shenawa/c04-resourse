#include<iostream>
using namespace std;
int main()
{
	int b,c,d;
	cin>>b>>c>>d;
	int a[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	int sum=0;
	if((b%400==0) or (b%4==0 and b%100!=0))
	{
		a[2]={29};
	}
	for(int i=0;i<c;i++)
	{
		sum+=a[i];
	}
	sum+=d;
	cout<<sum;
}
