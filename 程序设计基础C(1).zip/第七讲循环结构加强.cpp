//������ 
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int jg,sum=0,num=0;
	while(cin>>jg)
	{
		if(jg==11 or jg==22)
		{
			continue;
		}
		if(num==10)
		{
			break;
		}
		sum+=jg;
		num++;
	}
	cout<<sum;
}







