//�ж������� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a,b,c;
	cin>>a>>b>>c;
	//�ж϶���ʱ����Ϊwhile(cin>>a>>b>>c),�ж��������� 
	if(a+b>c&&a+c>b&&b+c>a)
	{
		cout<<"Yes";
	 } 
	else
	{
		cout<<"No";
	}
}



//�ж����� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a;
	cin>>a;
	if((a%400==0) or (a%4==0 and a%100!=0))
	{
		cout<<"Y";
	}
	else
	{
		cout<<"N";
	}
}



//�ж��Ƿ������ڵ������� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a,b,c;
	cin>>a>>b>>c;
	if((b-a==1&&c-b==1) || (c-a==1&&b-c==1) || (a-b==1&&c-b==1) || (b-c==1&&a-b==1) || (a-c==1&&c-b==1) || (b-a==1&&a-c==1))
	{
		cout<<"TRUE"<<ENDL;
	}
	else
	{
		cout<<"FALSE"<<endl;
	}
}



//�ж��Ǽ�λ�� 
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	long long/*������*/ n,m;
	cin>>n;
	int t=n;
	while(t>0)
	{
		t/=10;
		m++;
	}
	if(m%2==0)
	{
		cout<<n*n*n<<endl;
	}
	else
	{
		cout<<n*n<<endl;
	}
}



//�����ż�� 
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int a,s=0;
	cin>>a;
	for(int i=10000;i<=a;i++)
	{
		int b=i%10;
		int c=i/10%10;
		int d=i/100%10;
		int e=i/1000%10;
		int f=i/10000%10;
		if(b%2==0 and c%2==0 and d%2==0 and e%2==0 and f%2==0)
			s++;
	}
	cout<<s<<endl;
}



//�жϻ�����
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[100],t=0;
	while(n>0)
	{
		a[t++]=n%10;
		n/=10;
	}
	for(int i=0,j=t-1;i<j;i++,j--)
	{
		if(a[i]!=a[j])
		{
			cout<<"No";
		}
		else
		{
			cout<<"Yes";
		}
	}
	return 0;
}
