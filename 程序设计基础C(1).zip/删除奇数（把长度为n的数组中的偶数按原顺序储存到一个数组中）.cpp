#include <iostream>
using namespace std;
#define N 100
int fun(int c[],int m)
{
	int i,j;
	j=0;
	for(i=0;i<m;i++)
	{
		if(c[i]%2==0)
		{
			c[j]=c[i];
			j++;
		}
	}
	return j;
}
int main()
{
	int a[N],i,n,k;
	cin>>n;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
	}
	k=fun(a,n);
	cout<<"The number of even:"<<k<<endl;
	cout<<"The even:";
	for(i=0;i<k;i++)
	{
		cout<<a[i]<<' ';
	}
	cout<<endl;
}
