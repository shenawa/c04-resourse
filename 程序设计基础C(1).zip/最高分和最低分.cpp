#include <iostream>
#include <cmath>
using namespace std;
int maxGap(int*p,int n)
{
	int max=*p;
	int min=*p;
	for(int i=0;i<n;i++)
	{
		if(*(p+i)>max)
		{
			max=*(p+i);
		}
		if(*(p+i)<min)
		{
			min=*(p+i);
		}
	}
	return max-min;
}
int main()
{
	int n;
	cin>>n;
	int* a=new int [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	cout<<maxGap(a,n)<<endl;
	delete [] a; 
}

