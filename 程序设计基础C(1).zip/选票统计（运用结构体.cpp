#include <iostream>
#include <cstring>
using namespace std;
struct Person
{
	char name[20];
	int count=0;
};
int main()
{
	Person leader[3];
	int i,j;
	for(i=0;i<3;i++)
	{
		cin>>leader[i].name;
		leader[i].count=0;
	}
	char leader_name[20];
	for(i=0;i<10;i++)
	{
		cin>>leader_name;
		for(j=0;j<3;j++)
		{
			if(strcmp(leader[j].name,leader_name)==0)
			{
				leader[j].count++;
			}
		}
	}
	for(i=0;i<3;i++)
	{
		cout<<leader[i].name<<":"<<leader[i].count<<endl;
	}
	return 0;
}




//У԰���ִ��� 
#include <iostream>
#include <cstring>
using namespace std;
struct singer
{
	char name[20];
	char BorG[20];
	int count=0;
};
int main()
{
	singer competitor[5];
	int i,j;
	for(i=0;i<5;i++)
	{
		cin>>competitor[i].name>>competitor[i].BorG;
		competitor[i].count=0;
	}
	char competitor_name[20];
	int sum=0;
	int max=0;
	for(i=0;i<20;i++)
	{
		cin>>competitor_name;
		if(strcmp(competitor_name,"none")==0)
		{
			sum++;
			continue;
		}
		for(j=0;j<5;j++)
		{
			if(strcmp(competitor[j].name,competitor_name)==0)
			{
				competitor[j].count++;
				sum++;
				if(competitor[j].count>competitor[max].count)
				{
					max=j;
				}
			}
		}
	}
	cout<<"Congratulation!STAR:"<<competitor[max].name<<" "
	<<competitor[max].BorG<<" "<<competitor[max].count<<" "
	<<competitor[max].count*1.0/sum<<endl;
	return 0;
}
