//��ˮ��ˮ��ͷ
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n,i=0,s=0;
	cin>>n;
	while(s<n)
	{
		i++;
		s+=i;
	}
	cout<<i<<endl;
}

//��������
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n,s=0;
	cin>>n;
	while(n!=1)
	{
		if(n%2==1) 
		{
			n=3*n+1;
		}
		else
		{
			n=n/2;
		}
		s++;
	}
	cout<<s;
}
