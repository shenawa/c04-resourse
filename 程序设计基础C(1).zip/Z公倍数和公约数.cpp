//������ 
#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int m,n,s;
	cin>>m>>n;
	for(s=m;s%n!=0;s=s+m);
	cout<<s<<endl;
	return 0;
}
//շת������󹫱��� 
#include <iostream>
using namespace std;
int gys(int a,int b)
{
	while(a%b!=0)
   {
	    int t=a%b;
	    a=b;
	    b=t;
   }
    return b;
}
int main()
{
	int a,b;
    cin>>a>>b;
    cout<<a*b/gys(a,b);
}




//���Լ������С������
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{
	int m,n,gbs,gys;
	cin>>m>>n;
	for(gys=m;gys%n!=0;gys=gys+m);
	gbs=m*n/gys;
	cout<<gys<<" "<<gbs<<endl;
	return 0;
}



int a,b,t;
cin>>a>>b;
cout<<a*b/gbs(a,b);
while(a%b!=0)
{
	int t=a%b;
	a=b;
	b=t;
}
return b;

