#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int a[105][105];
int kill(int i,int j,int n)
{
	if(i==n)
	{
		return a[i][j];
	}
	int zxf=kill(i+1,j,n);
	int yxf=kill(i+1,j+1,n);
	return a[i][j]+max(zxf,yxf);
}
int able(int i,int j,int n)
{
	if(i==n)
	{
		return a[i][j];
	}
	int zxf=able(i+1,j,n);
	int yxf=able(i+1,j+1,n);
	return a[i][j]+min(zxf,yxf);
}
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
		{
			cin>>a[i][j];
		}
	}
	cout<<kill(1,1,n)<<" "<<able(1,1,n)<<endl;
}
