#include <iostream>
using namespace std;
int main()
{
	int a,b,c;
	for(a=1;a<10;a++)
	{
		for(b=1;b<10;b++)
		{
			for(c=1;c<10;c++)
			{
				if((a*100+b*10+c)+(c*100+b*10+a)==1333)
				{
					cout<<"a="<<a<<",b="<<b<<",c="<<c<<endl;
				}
			}
		}
	}
}
