//���������Σ�����һ�ж���
   1
  222
 33333 
#include <iostream>
using namespace std;
int main()
{
	int i,j,n;
	cin>>n;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++)
		{
			cout<<" ";
		}
		for(j=0;j<2*i-1;j++)
		{
			cout<<i;
		}
		cout<<endl;
	}
}


#include<iostream>
#include <ioamnip>
using namespace std;
int main()
{
	int n;
	cn>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
		{
			int t=1;
			for(int fz=i-1,fm=1;fm<=j-1;fm++,fz--)
			{
				t=t*fz/fm;
			}
			cout<<setw(6)<<t;
		}
		cout<<"\n";
	}
 } 



//�ַ������Σ������������Σ�����һ�ж���ͬ���� 
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n;
	char c;
	cin>>c>>n;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n-i;j++)
			cout<<" ";
		for(int j=1;j<=2*i-1;j++)
			cout<<c;
		cout<<endl;
	}
}


//�ַ������Σ���A��ʼ��һֱ��Z�󻻻�A������ 
 A
 BC
 DEF
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	char c='A';
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
		{
			cout<<c;
			c++;
			if(c>'Z')
			{
				c='A';
			}
		}
	
		cout<<endl;
	}
}



//�ַ�������
    A
   ABC
  ABCDE 
#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int n,i;
	for( n=1;n<=10;++n)
	{
		for(i=1;i<=10-n;++i)
		cout<<" ";
		for(char j='A';j<'A'+2*n-1;j++)
		cout<<j;
		cout<<endl;
	}
	return 0;
}



//���һ������
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int h,w;
	char c;
	cin>>h>>c>>w;
	for(int i=1;i<=h;i++){
		for(int j=1;j<=w;j++){
			cout<<"*";
		}
		cout<<endl;
	}
} 



//�ַ�����
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n;
	char c;
	cin>>c>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n-i;j++)
			cout<<" ";
		for(int j=1;j<=2*i-1;j++)
			cout<<c;
			cout<<endl;
	}
	for(int i=n-1;i>=1;i--)
	{
		for(int j=1;j<=n-i;j++)
			cout<<" ";
		for(int j=1;j<=2*i-1;j++)
			cout<<c;
			cout<<endl;
	}
} 



//����ֱ��2��n�У���n�����һ������Ϊn�� 
1
12
123
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	for (int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
			cout<<j;
			cout<<endl;
	}
}



//���������Σ���1��ʼ��ֱ��0�������¿�ʼ����һ��ʼ�Ͷ���
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n,a=1;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
		cout<<(a++)%10;
		cout<<endl;
	}
}



//�����ַ��������� 
STSTS
 TST
  S
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	for(int i=n;i>=1;i--)
	{
		for(int j=1;j<=n-i;j++)
		{
			cout<<" ";
		}
		for(int j=1;j<=2*i-1;j++)
		{
			if(j%2==1) cout<<"S";
			else cout<<"T";
		}
		cout<<endl;
	}
}



//�������ַ�������
  w w
 ww ww
www www
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	char a;
	int n;
	cin>>a>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n-i;j++)
			cout<<" ";
		for(int j=1;j<=i;j++)
			cout<<a;
			cout<<" ";
		for(int j=1;j<=i;j++)
			cout<<a;
			cout<<endl;
	}
	
}



//ƽ���ı���
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{
	int a,b;
	char c;
	cin>>a>>b>>c;
	for(int i=b;i>=1;i--)
	{
		for(int j=1;j<=b-i;j++)
		{
			cout<<" ";
		}
		for(int j=1;j<=a;j++)
		{
			cout<<c;
		}
		cout<<endl;
	}
}



//����������
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n-i;j++)
		{
			cout<<" ";
		}
		for(int j=1;j<=2*i-1;j++)
		{
			if(j%3==1) cout<<"Z";
			else if(j%3==2) cout<<"Y";
			else cout<<"L";
		}
		cout<<endl;
	}
}



//С���H�־���
#include<cstdio> 
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int N;
	cin>>N;
	for(int i=1;i<=N;i++)
	{
		cout<<"|";
		for(int j=2;j<N;j++)
		{
			if(i==(N+1)/2)
			{
				cout<<"-";
			}
			else
			{
				cout<<"a";
			}
		}
		cout<<"|"<<endl;
	}
	
}


// ��ӡ
*******
**   **
* * * *
*  *  *
* * * *
**   **
*******
#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
		cout<<"*";
	cout<<endl;
	for(int i=2;i<=n-1;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(j==1 || j==i ||j==n ||j=n-i+1)
				cout<<"*";
			else cout<<" ";
		}
		cout<<endl;
	}
	for(int i=n;i>=1;i--)
	{
		cout<<"*";
	}
}




