//�������д���k�����ֻ������ֵ��С��k�����ֻ�����Сֵ 
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	long long n,k;
	cin>>n>>k;
	int a[100010];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	int max=a[0];
	int min=a[0];
	for(int i=0;i<n;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
		}
		if(a[i]>max)
		{
			max=a[i];
		}
	}
	for(int i=0;i<n;i++)
	{
		if(a[i]<k)
		{
			a[i]=min;
		}
		else if(a[i]>k)
		{
			a[i]=max;
		}
		cout<<a[i]<<" ";
	}
}


//
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int n,sum=0;
	cin>>n;
	int b[1000];
	for(int i=0;i<n;i++)
	{
		cin>>b[i]; 
	}
	for(int i=0;i<n;i++)
	{
		sum+=b[i];
	}
	double avg=sum/n;
	int max=b[0],min=b[0];
	for(int i=1;i<=n;i++)
	{
		if(b[i]>max)
		{
			max=b[i];
		}
		if(b[i]<min)
		{
			min=b[i];
		}
	}
	for(int i=0;i<n;i++)
	{
		if(b[i]>avg)
		{
			b[i]=max;
		}
		else
		{
			b[i]=min;
		}
		cout<<b[i]<<" ";
	}
}
