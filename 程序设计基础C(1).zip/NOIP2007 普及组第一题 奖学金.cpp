#include <iostream>
using namespace std;
struct stu
{
	int xh,sum,yw,sx,yy;
};
int main()
{
	int n;
	cin>>n;
	stu* a=new stu [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i].yw >>a[i].sx >>a[i].yy ;
		a[i].sum=a[i].yw +a[i].sx +a[i].yy ;
		a[i].xh =i+1;
	}
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(a[j].sum<a[j+1].sum 
			||a[j].sum ==a[j+1].sum &&a[j].yw <a[j+1].yw 
			||a[j].sum ==a[j+1].sum && a[j].yw==a[j+1].yw &&a[j].xh <a[j+1].xh)
			{
				swap(a[j],a[j+1]);
			}
		}
	}
	for(int i=0;i<5;i++)
	{
		cout<<a[i].xh <<" "<<a[i].sum <<endl;
	}
	delete [] a;
	a=NULL;
}
