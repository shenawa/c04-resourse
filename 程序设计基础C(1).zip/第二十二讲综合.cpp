//��� 
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int x,y;
	cin>>x>>y;
	double sum1=x;
	double sum2=y;
	if(x<y)
	{
		sum1=sum1-1.0*x/2;
		sum2=sum2+1.0*x/2;
		cout<<fixed<<setprecision(1)<<sum1<<" "<<sum2;
	}
	else
	{
		sum1=sum1+1.0*y/2;
		sum2=sum2-1.0*y/2;
		cout<<fixed<<setprecision(1)<<sum1<<" "<<sum2;
	}
	return 0;
} 
 
 

//��ȫƽ���� 
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	long long n;
	cin>>n;
	int i;
	for(i=1;i*i<=n;i++)
	{
		if(i*i==n)
		{
			cout<<i;
			return 0;
		}
	}
	cout<<i*i;
} 



//������������� 
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(i==0||i==n-1||j==0||j==n-1)
			{
				cout<<"*";
			}
			else
			{
				cout<<" ";
			}
		}
		cout<<endl;
	} 
	return 0;
}



//С�ֹ��� ����nԪ��������Ʒ���۷ֱ�Ϊa��b������Ʒ�������ܳ���2��������ܹ���������� 
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	long long n,a,b;
	cin>>n>>a>>b;
	int sum1=0,ans=0;
	for(sum1=0;sum1<n/a;sum1++)
	{
		long long money=(n-a*sum1)/b;
		if(abs(sum1-money)<=2 && (sum1+money)>ans)
		ans=sum1+money;
	}
	cout<<ans;
} 



//�м�ͬѧ�����ߣ��ҵ���ߺ��ͬѧ����������м��˵�ѧ�ź����ߣ� 
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[105];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	} 
	int zg=a[0],zgpos=1;
	int za=a[0],zapos=1;
	for(int i=1;i<n;i++)
	{
		if(a[i]>zg)
		{
			zg=a[i];
			zgpos=i+1;
		}
		if(a[i]<za)
		{
			za=a[i];
			zapos=i+1;
		}
	}
	for(int i=zgpos;i<zapos-1;i++)
	{
		cout<<i+1<<" "<<a[i]<<endl;
	}
}



//ÿ�е������Сֵ 
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int h,w;
	cin>>h>>w;
	int a[h][w];
	for(int i=0;i<h;i++)
	{
		for(int j=0;j<w;j++)
		{
			cin>>a[i][j];
		}
	}
	for(int i=0;i<h;i++)
	{
		int zd=a[i][0];
		int zx=a[i][0];
		for(int j=1;j<w;j++)
		{
			if(a[i][j]>zd)
			{
				zd=a[i][j];
			}
			if(a[i][j]<zx)
			{
				zx=a[i][j];
			}
		}
		cout<<zd<<","<<zx<<endl;
	}
}



//�ڰ׷�ת 
#include <iostream>
#include <cmath>
#include <iomanip>
#include <cstring>
using namespace std;
int main()
{
	long long n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int x;
		cin>>x;
		char s[n];
		cin>>s;
		int first=1,last=1;
		for(int j=0;j<n;j++)
		{
			if(s[j]=='B')
			{
				first=j;
				break;
			}
		}
		for(int j=n-1;j>=0;j--)
		{
			if(s[j]=='B')
			{
				last=j;
				break;
			}
		}
		int ans=last-first+1;
		cout<<ans<<endl;
	}
	return 0;
}



//��ʱ����������
 1 12 11 10
 2 13 16  9
 3 14 15  8
 4  5  6  7
#include <iostream>
#include <cmath>
#include <cstring>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[n+1][n+1];
	memset(a,0,sizeof(int)*(n+1)*(n+1));
	int hang=1,lie=1,t=1;
	while(t<=n*n)
	{
		while(hang<=n && a[hang][lie]==0)
			a[hang++][lie]=t++;
		hang--,lie++;
		while(lie<=n && a[hang][lie]==0)
			a[hang][lie++]=t++;
		hang--,lie--;
		while(hang>=1 && a[hang][lie]==0)
			a[hang--][lie]=t++;
		hang++,lie--;
		while(lie>=1 && a[hang][lie]==0)
			a[hang][lie--]=t++;
		hang++,lie++;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			printf("%4d",a[i][j]);
		}
		printf("\n");
	}
}



//�������������Ϊ2���������������� 
#include <iostream>
using namespace std;
int m,n=0;
bool ss(int a)
{
	bool flag=true;
	int k=2;
	while(k<=a/2 && flag)
	{
		if(a%k==0)
		{
			flag=false;
		}
		else
		{
			k++;
		}
	}
	return flag; 
}
int main()
{
	int k=2;
	cin>>m;
	do
	{
		if(ss(k) && ss(k+2))
		{
			n++;
			cout<<k<<' '<<k+2<<endl;
		}
		k++
	}while(n!=m);
	return 0;
}





//�����Լ����
#include <cstdio>
using namespace std;
int n;
void Produce(int a,int b,int c,int d)
{
	if(b+d>n) return;
	Produce(a,b,a+c,b+d);
	printf("%d/%d\n",a+c,b+d);
	Produce(a+c,b+d,c,d);
} 
int main()
{
	while(~sccanf("%d",&n))
	{
		printf("***%d***\n",n);
		printf("%d/%d\n",0,1);
		Produce(0,1,1,1);
		printf("%d/%d\n",1,1);
	}
}



//������ 
#include <iostream>
#include <iomanip>
#include <camth>
#include <cstdio>
using namespace std;
int n;
const int max_size=1<<10;
int res[max_size][max_size];
void recursive(int x,int y,int n,int t)
{
	if(n==0)
	{
		res[x][y]=t;
		return;
	}
	int step=1<<(n-1);
	recursive(x,y,n-1,t);
	recursive(x,y+step,n-1,t);
	recursive(x+step,y,n-1,t);
	recursive(x+step,y+step,n-1,!t);
}
int main()
{
	scanf("%d",&n);
	recursive(0,0,n,0);
	int size=1<<n;
	for(int i=0;i<size;++i)
	{
		for(int j=0;j<size;++j)
		printf("%d",res[i][j]);
		puts("");
	}
	return 0;
}
