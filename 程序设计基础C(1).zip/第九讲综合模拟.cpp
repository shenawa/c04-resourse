#include <cstdio>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int l,r,sum=0;
	cin>>l>>r;
	for(int x=0;x<=30;x++)
	{
		for(int y=x;y<=30;y++)
		{
			int n=(1<<x)+(1<<y);
			if(n>=l and n<=r)
			{
				sum++;
			}
		}
	}
	cout<<sum;
}

#include <cstdio>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int n,sum=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
		{
			if((i*j)%2==0)
			{
				sum++;
			}
		}
	}
	cout<<sum<<endl;
	return 0;
}


#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int n,k,t,s;
	cin>>n>>k>>t;
	if(k*t>=n)
	{
		s=n;
		cout<<s<<endl;
	}
	else
	{
		s=k*t;
		cout<<s<<endl;
	}
}
