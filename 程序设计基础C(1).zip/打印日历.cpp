#include <iostream>
using namespace std;
const int dayNum[]={-1,31,29,31,30,31,30,31,31,30,31,30,31};
int m,offset,i;
int main()
{
	cin>>m;
	cout<<"S\tM\tT\tW\tT\tF\tS"<<endl;
	offset=3;
	for( i=1;i<m;i++)
		offset=(offset+dayNum[i])%7;
	for( i=0;i<offset;i++)
	    cout<<'\t';
	for( i=1;i<=dayNum[m];i++)
	{
		cout<<i;
		if(i==dayNum[m]||(i+offset)%7==0)
			cout<<endl;
		else
			cout<<'\t';
	}
	return 0;
}



//���� 
#include <iostream>
#include <cstdio>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int m;
	cin>>m;
	cout<<"MON"<<" "<<"TUE"<<" "<<"WED"<<" "<<"THU"<<" "<<"FRI"<<" "<<"SAT"<<" "<<"SUN"<<endl;
	int a[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	int b[13]={0,2,5,5,1,3,6,1,4,0,2,5,0};
	int c=a[m];
	int d=b[m];
	int e=1;
	for(int i=0;i<6;i++)
	{
		for(int j=0;j<7;j++)
		{
			if(i==0 and j<d)
			{
				cout<<"    ";
			}
			else if(e>c)
			{
				cout<<"    ";
			}
			else
			{
				cout<<setw(3)<<e<<" ";
				e++;
			}
		}
		cout<<endl;
		if(e>c) break;
	}
}
