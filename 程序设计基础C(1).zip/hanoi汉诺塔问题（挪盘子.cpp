#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
void hanoi(int n,char a,char b,char c)
{
	if(n==0) return;
	hanoi(n-1,a,c,b);
	cout<<n<<" "<<a<<" "<<b<<endl;
	hanoi(n-1,c,b,a);
}
int main()
{
	int n;
	cin>>n;
	hanoi(n,'A','B','C');
	return 0;
}
