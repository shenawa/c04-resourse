//ʮ����ת������
#include <iostream>
#include <cstdio>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[1000],k=0;
	while(n>0)
	{
		a[k++]=n%2;
		n/=2;
	}
	for(int i=k-1;i>=0;i--)
	{
		cout<<a[i];
	}
}


//ʮ����ת��Ϊ�˽���
#include <iostream>
#include <cstdio>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[1000],k=0;
	while(n>0)
	{
		a[k++]=n%8;
		n/=8;
	}
	for(int i=k-1;i>=0;i--)
	{
		cout<<a[i];
	}
}

#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	printf("%o",n);
}
//ʮ������ת����ʮ��������
#include <iostream>
#include <cstdio>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[1000],k=0;
	while(n>0)
	{
		a[k++]=n%16;
		n/=16;
	}
	for(int i=k-1;i>=0;i--)
	{
		if(a[i]<10)
		{
			cout<<a[i];
		}
		else
		{
			cout<<char('A'-10+a[i]);
		}
	}
}

#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	printf("%X",n);
}


//������ת��Ϊʮ����
#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[1000],k=0;
	
}
//�˽���ת��Ϊʮ����
#include <iostream>
using namespace std;
int main()
{
	
}
//ʮ������ת��Ϊʮ����
#include <iostream>
using namespace std;
int main()
{
	
}



//ת��������ĸ 
#include <cstdio>
#include <iostream>
#include <cctype>
using namespace std;
int main()
{
	char lc;
	cin>>lc;
	if(isalpha(lc))
	{
		char xt = tolower(lc);
		int position = xt-'a';
		cout<<position<<endl;
	}
	else if(isdigit(lc))
	{
		char letter = 'A'+(lc-'0');
		cout<<letter<<endl;
	}
}
