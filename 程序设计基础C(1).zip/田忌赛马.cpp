#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
long long ans(long long n,long long *a,long long *b)
{
	for(int i=1;i<n;i++)
	{
		int key=a[i];
		int j=i-1;
		while(j>=0&&a[j]>key)
		{
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=key;
	}
	for(int k=1;k<n;k++)
	{
		int sum=b[k];
		int t=k-1;
		while(t>=0&&b[t]>sum)
		{
			b[t+1]=b[t];
			t--;
		}
		b[t+1]=sum;
	}
	int win=0;
	int afast=n-1;
	int bfast=n-1;
	int aslow=0;
	int bslow=0;
	while(aslow<=afast)
	{
		if(a[afast]>b[bfast])
		{
			win++;
			afast--;
			bfast--;
		}
		else if(a[afast]<b[bfast])
		{
			aslow++;
			bfast--;
		}
	}
	return win;
}
int main()
{
	long long n;
	cin>>n;
	long long *a=new long long [n];
	long long *b=new long long [n];
	for(int i=0;i<n;i++) cin>>a[i];
	for(int i=0;i<n;i++) cin>>b[i];	
	cout<<ans(n,a,b)<<endl;
	delete []a;
	delete []b;
	return 0;
}
