#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	double x,y;
	cin>>x;
	if (x < 0 || x >= 10) {
    cout << "Input error!" << endl;
    return 0; 
    } 
	else {
    if (x < 2) y = 0;
    else if (x < 5) y = 3 + x/2;
    else if (x < 8) y = sqrt(x) + 6;
    else if (x < 10) y = x*x;
    cout << "y=" << fixed << setprecision(1) << y << endl;
    }
}


#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
int main()
{
	char c[101];
	gets(c);
	int len=strlen(c);
	for(int i=0;i<len-1;i++)
	{
		int k=i;
		for(int j=i+1;j<len;j++)
		{
			if(c[j]<c[k])
				k=j;
		}
		swap(c[i],c[k]);
	}
	for(int i=0;i<len;i++)
	{
		if(c[i]%3==0) continue;
		cout<<c[i];
	}
}


#include <iostream>
#include <cstring>
using namespace std;
const int N=5;
struct STUDENT
{
	char num[15];
	char name[31];
	float score[4];
};
void sortNum(STUDENT* stu)
{
	for(int i=0;i<N-1;i++)
	{
		for(int j=0;j<N-1-i;j++)
		{
			if(strcmp(stu[j].num,stu[j+1].num)>0)
			{
				swap(stu[j],stu[j+1]);
			}
		}
	}
}
void printAll(STUDENT* stu)
{
	for(int i=0;i<N;i++)
	{
		cout<<stu[i].num <<'\t'<<stu[i].name <<'\t'<<stu[i].score [0]
		<<'\t'<<stu[i].score [1]<<'\t'<<stu[i].score [2]<<'\t'<<
		stu[i].score [3]<<endl;
	}
}
void printTopOne(STUDENT* stu)
{
	int first=0,grade=stu[0].score [0]+stu[0].score [1]+stu[0].score [2]+stu[0].score [3];
	for(int i=1;i<N;i++)
	{
		int temp=stu[i].score [0]+stu[i].score [1]+
	                  stu[i].score [2]+stu[i].score [3];
	    if(temp>grade)
	    {
	    	grade=temp;
	    	first=i;
		}
	}
	cout<<stu[first].num <<" "<<stu[first].name <<" "<<grade;
}
int main()
{
	STUDENT stu[N];
	int i,j;
	for(i=0;i<N;++i)
	{
		cin>>stu[i].num >>stu[i].name ;
		for(j=0;j<4;++j)
		{
			cin>>stu[i].score [j];
		}
	}
	sortNum(stu);
	cout<<"NO."<<'\t'<<"Name"<<'\t'<<"Chinese"<<'\t'<<"Maths"<<'\t'<<"Eng"<<'\t'<<"Comps"<<endl;
	printAll(stu);
	cout<<"The top one is��";
	printTopOne(stu);
	return 0;
}




#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
const int N=5;
struct STUDENT
{
	char num[15];
	char name[31];
	float score[4];
};
void sortNum(STUDENT* stu)
{
	for(int i=0;i<N-1;i++)
	{
		int k=i;
		for(int j=i+1;j<N;j++)
		{
			if(strcmp(stu[j].num ,stu[k].num )<0)
			{
				k=j;
			}
		}
		swap(stu[i],stu[k]);
	}
}
void printAll(STUDENT* stu)
{
	for(int i=0;i<N;i++)
	{
		cout<<stu[i].num <<'\t'<<stu[i].name <<'\t'<<stu[i].score [0]
		<<'\t'<<stu[i].score [1]<<'\t'<<stu[i].score [2]<<'\t'<<
		stu[i].score [3]<<endl;
	}
}
void printTopOne(STUDENT* stu)
{
	int first=0,grade=stu[0].score [0]+stu[0].score [1]+stu[0].score [2]+stu[0].score [3];
	for(int i=1;i<N;i++)
	{
		int temp=stu[i].score [0]+stu[i].score [1]+
	                  stu[i].score [2]+stu[i].score [3];
	    if(temp>grade)
	    {
	    	grade=temp;
	    	first=i;
		}
	}
	cout<<stu[first].num <<" "<<stu[first].name <<" "<<grade;
}
int main()
{
	STUDENT stu[N];
	int i,j;
	for(i=0;i<N;++i)
	{
		cin>>stu[i].num >>stu[i].name ;
		for(j=0;j<4;++j)
		{
			cin>>stu[i].score [j];
		}
	}
	sortNum(stu);
	cout<<"NO."<<'\t'<<"Name"<<'\t'<<"Chinese"<<'\t'<<"Maths"<<'\t'
	<<"Eng"<<'\t'<<"Comps"<<endl;
	printAll(stu);
	cout<<"The top one is�� ";
	printTopOne(stu);
	return 0;
}


void printTopOne(STUDENT stu[])
{
	int first=0,grade=stu[0].score [0]+stu[0].score [1]+
	                  stu[0].score [2]+stu[0].score [3];
	for(int i=1;i<N;i++)
	{
		int temp=stu[i].score [0]+stu[i].score [1]+
	                  stu[i].score [2]+stu[i].score [3];
	    if(temp>grade)
	    {
	    	grade=temp;
	    	first=i;
		}
	}
	cout<<stu[first].num <<" "<<stu[first].name <<" "<<grade;
}




#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
const int N=5;
struct STUDENT
{
	char num[15];
	char name[31];
	float score[4];
};
void sortNum(STUDENT* stu);
void printAll(STUDENT* stu);
void printTopOne(STUDENT* stu);
int main()
{
	STUDENT stu[N];
	int i,j;
	for(i=0;i<N;++i)
	{
		cin>>stu[i].num >>stu[i].name ;
		for(j=0;j<4;++j)
		{
			cin>>stu[i].score [j];
		}
	}
	sortNum(stu);
	cout<<"NO."<<'\t'<<"Name"<<'\t'<<"Chinese"<<'\t'<<"Maths"<<'\t'
	<<"Eng"<<'\t'<<"Comps"<<endl;
	printAll(stu);
	cout<<"The top one is�� ";
	printTopOne(stu);
	return 0;
}
void sortNum(STUDENT* stu)
{
	for(int i=0;i<N-1;++i)
	{
		for(int j=0;j<N-1-i;++j)
		{
			if(strcmp(stu[j].num,stu[j+1].num)>0)
			{
				STUDENT temp=stu[j+1]; stu[j+1]=stu[j];stu[j]=stu[j+1];
			}
		}
	}
}
void printAll(STUDENT* stu)
{
	for(int i=0;i<N;++i)
	{
		cout<<stu[i].num <<'\t'<<stu[i].name <<'\t';
		for(int j=0;j<4;++j)
		{
			cout<<stu[i].score[j]<<'\t';
		}
		cout<<endl;
	}
}
void printTopOne(STUDENT* stu){
     float max=0,sum;  
     int maxi=0;       
     for(int i=0;i<N;++i){
         sum=0;       
         for(int j=0;j<4;++j){
             sum+=stu[i].score[j];
         }
         if(sum>max){
             max=sum;
             maxi=i;
         }
     }
     cout<<stu[maxi].num<<'\t'<<stu[maxi].name<<'\t'<<max<<endl;
 }

#include <iostream>
#include <cstring>
using namespace std;
int main()
{
	char c[110];
	gets(c);
	char s[220];
	int len=strlen(c);
	for(int i=0;i<len;i++)
	{
		s[i]=c[len-1-i];
	}
	s[len]='\0';
	cout<<c<<s<<endl;
	return 0;
}



#include <iostream>
#include <cmath>
using namespace std;
int szh(int n)
{
	int sum=0;
	while(n>0)
	{
		sum+=n%10;
		n/=10;
	}
	return sum;
}
int main()
{
	int ans=0;
	for(int i=100;i<=999;i++)
	{
		if((szh(i)%2)==0) 
		{
			cout<<i<<endl;
			ans++;
		}
	}
	cout<<ans<<endl;
	return 0;
}
