#include <cstdio>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	double x0,x1,a;
	cin>>a;
	x1=a/2;
	do
	{
		x0=x1;
		x1=(x0+a/x0)/2;
	}while(fabs(x1-x0)>=1e-8);//��ѭ�������㹻��ʹ�������ֵ�Ĳ�С��10��-8�η���������ѭ����ִ����һ����� 
	//�ֺŴ����þ伴Ϊһѭ�� 
	cout<<fixed<<setprecision(8)<<x1<<endl;
	return 0;
}


#include<iostream>
#include<cstdlib>
using namespace std;
int main()
{
	int n,k;
	cin>>n;
	int a[n];//int *a=(int*)malloc(sizeof(int)*n);
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<n-1;i++)
	{
		k=i;
		for(int j=i+1;j<n;j++)
		{
			if(a[j]<a[k])
			{
				k=j;
			}
		}
		if(k!=i)
		{
			swap(a[i],a[k]);
		}
	}
	for(int i=0;i<n;i++)
	cout<<a[i]<<endl;
	//free(a);
	return 0;
}


#include <cstdio>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	int m;
	cin>>m;
	for(int i=0;i<m;i++)
	{
		int n;
		cin>>n;
		char a[21];
		int s=0;
		if(n==0)
		{
			cout<<"0"<<endl;
			continue;
		}
		while(n>0)
		{
			int x=n%16;
			if(x<10)
			{
				a[s]='0'+x;
			}
			else
			{
				a[s]='A'+x-10;
			}
			s++;
			n/=16;
		}
		for(int i=s-1;i>=0;i--)
		{
			cout<<a[i];
		}
		cout<<endl;
	}
	return 0;
}


#include <iostream>
using namespace std;
int a[101];
int n,i,ans,len,tmp,beg;
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	tmp=0;
	ans=0;
	len=0;
	beg=0;
	for(int i=1;i<=n;i++)
	{
		if(tmp+a[i]>ans)
		{
			ans=tmp+a[i];
			len=i-beg;
		}
		else if(tmp+a[i]==ans&&i-beg>len)
		{
			len=i-beg;
		}
		if(tmp+a[i]<=0)
		{
			beg=i;
			tmp=0;
		}
		else
		    tmp+=a[i];
	}
	cout<<ans<<" "<<len<<endl;
} 
