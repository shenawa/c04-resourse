#include <iostream>
using namespace std;
struct Data
{
	int value;
	int num;
};
void mySwap(Data *p1, Data *p2)
{
	Data t=*p1;
	*p1=*p2;
	*p2=t;
}
int main()
{
	int n,x;
	cin>>n;
	int cnt[201]={0};
	for(int i=0;i<n;++i)
	{
		cin>>x;
		++cnt[x+100];
	}
	struct Data a[101];
	n=0;
	for(int i=0;i<201;i++)
	{
		if(cnt[i])
		{
			a[n].value=i-100;
			a[n].num = cnt[i];
			++n;
		}
	}
	for(int i=0;i<n-1;++i)
	{
		for(int j=0;j<n-i-1;++j)
		{
			if(a[j].num>a[j+1].num || a[j].num==a[j+1].num&&a[j].value>a[j+1].value)
			{
				mySwap(a+j,a+j+1);
			}
		}
	}
	for(int i=0;i<n;++i)
	{
		while(a[i].num)
		{
			cout<<a[i].value<<" ";
			--a[i].num;
		}
	}
	cout<<endl;
}
