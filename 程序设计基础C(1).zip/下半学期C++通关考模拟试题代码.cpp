#include <iostream>
using namespace std;

int main() {
    int n;
    // �������룬ֱ���������
    while (cin >> n) {
        for (int i = 0; i < n; ++i) {
            int a, b, c, d, e;
            cin >> a >> b >> c >> d >> e;
            int sum = a + b + c + d + e;
            int mod = sum % 26;
            // ת��ΪСд��ĸ�����
            cout << char('a' + mod) << endl;
        }
    }
    return 0;
}
#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[n][5];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<5;j++)
		{
			cin>>a[i][j];
		}
	}
	for(int i=0;i<n;i++)
	{
		int sum=0;
		for(int j=0;j<5;j++)
		{
			sum+=a[i][j];
		}
		int s=sum%26;
		cout<<char('a'+s)<<endl;
	}
	return 0;
}



#include <iostream>
using namespace std;
int main()
{
	int n;
	if(!(cin>>n)) return 0;
	int x=1;
	for(int i=0;i<n;i++)
	{
		int a,b;
		cin>>a>>b;
		while(a%b!=0)
        {
	        int t=a%b;
	        a=b;
	        b=t;
        }
        cout<<"Case "<<x++<<": "<<b<<endl;
	}
	return 0;
}


//������������ 
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	double a,b,c,d;
	while(cin>>a>>b>>c>>d)
	{
		double result=sqrt((a-c)*(a-c)+(b-d)*(b-d));
		cout<<fixed<<setprecision(2)<<result<<endl;
	}
	return 0;
}



//PalindromepA�жϻ��Ĵ�����
#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
using namespace std;
int main()
{
	string s;
	while(cin>>s)
	{
		if(s=="0") break;
		bool flag=true;
		int len=s.size();
		for(int i=0;i<len/2;i++)
		{
			if(s[i]!=s[len-i-1])
			{
				flag=false;
				break;
			}
		} 
		if(flag) cout<<"Yes"<<endl;
		else cout<<"No"<<endl;
	}
	return 0;
}


//�ϲ��б����ҵ���ͬ���������������ʱ��������
 #include <iostream>
using namespace std;
int main()
{
    int n, m;
    while(cin >> n)
    {
        int a[1005], b[1005], c[2005];
        for(int i = 0; i < n; i++)
        {
            cin >> a[i];
            c[i] = a[i];
        }
        cin >> m;
        for(int i = 0; i < m; i++)
        {
            cin >> b[i];
            c[n + i] = b[i];
        }
        int len = n + m;
        for(int i = 0; i < len - 1; i++)
        {
            for(int j = 0; j < len - 1 - i; j++)
            {
                if(c[j] > c[j+1])
                {
                    int temp = c[j];
                    c[j] = c[j+1];
                    c[j+1] = temp;
                }
            }
        }
        for(int i = 0; i < len; i++)
        {
            if(i != 0) cout << " ";
            cout << c[i];
        }
        cout << endl;
    }
    return 0;
}


//
#include <iostream>
using namespace std;
int main() {
    int N, K;
    bool first_case = true;
    const int MAX_N = 1000;
    bool light[MAX_N + 1];
    while (cin >> N >> K) 
	{
        if (!first_case) 
		{
            cout << endl; 
        }
        first_case = false;
        for (int i = 1; i <= N; ++i) 
		{
            light[i] = false;
        }
        for (int i = 1; i <= K; ++i) 
		{
            for (int j = i; j <= N; j += i) 
			{
                light[j] = !light[j]; 
            }
        }
        bool first_num = true;
        for (int i = 1; i <= N; ++i) 
		{
            if (light[i]) {
                if (!first_num) 
				{
                    cout << " ";
                }
                cout << i;
                first_num = false;
            }
        }
        cout << endl;
    }
    return 0;
}

//�ж��Ƿ�Ϊ2��k�η� 
#include <iostream>
using namespace std;
int main() 
{
    int n;
    cin>>n;
    while(n--)
    {
    	int x;
    	cin>>x;
    	bool flag=true;
    	while(x!=1)
    	{
    		if(x%2!=0)
    		{
    			flag=false;
    			break;
			}
			x=x/2;
		}
		if(flag) cout<<"Yes"<<endl;
		else cout<<"No"<<endl;
	}
    return 0;
}



//�����ַ���
#include <iostream>
#include <cstring> 
using namespace std;
int main() 
{
    int n;
    cin>>n;
    while(n--)
    {
    	string s1,s2;
    	cin>>s1>>s2;//��ȡʱ�Զ��Կո�Ϊ�ָ�����ȡ�����ַ��� 
    	cout<<s1+s2<<endl;
	}
	return 0;
}

//�Ӽ�����ȡ�� 
#include <iostream>
#include <cstring> 
using namespace std;
int main() 
{
    int N;
	cin>>N;
	while(N--)
	{
		int m,p;
		cin>>m>>p;
		while(p--)
		{
		    int t,k;
		    cin>>t>>k;
			switch(t)
		    {
			    case 1:m=m+k;
			    break;
			    case 2:m=m-k;
			    break;
			    case 3:m=m*k;
			    break;
			    case 4:m=m/k;
			    break;
			    case 5:m=m%k;
			    break;
			    default:break;
		    }
		}
		cout<<m<<endl;
	} 
	return 0;
}


// �ַ������� 
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{
	int n;
	while(cin>>n)
	{
		for(int i=n;i>=1;i--)
	    {
		for(int j=1;j<=i;j++)
		   {
			cout<<"*";
		   }
		cout<<endl;
	    }
	}
	return 0;
}


//ŷ����·
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{	
	int n,m;
	while(cin>>n>>m)
	{
		int a,b;
		int *s=new int [m];
		int *t=new int [m];
		for(int i=0;i<m;i++)
		{
			cin>>a>>b;
			s[i++]=a;
			t[i++]=b;
		}
		if()
	}
	return 0;
}



//������
 
