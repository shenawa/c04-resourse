#include <iostream>
#include <cmath>
using namespace std;
bool prime(int p)
{
	if(p<=1)    return false;
	if(p<4)     return true;
	if(p%2==0)  return false;
	for(int i=3;i<=(int)sqrt(p);i+=2)
	{
		if(p%i==0)
		{
			return false;
		}
	}
	return true; 
}
void gotbaha(int n)
{
	int i;
	for(i=2;i<n/2;i++)
	{
		int j=n-i;
		if(prime(i)&&prime(j))
		{
			cout<<n<<"="<<i<<"+"<<j<<endl;
			break;
		}
	}
}
int main()
{
	int n;
	cin>>n;
	if(n<6 || n%2!=0) return 0;
	else gotbaha(n);
	return 0;
}
