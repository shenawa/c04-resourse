#include <iostream>
using namespace std;
double qpower(double x,int n)
{
	if(n==0) return 1;
	if(n==1) return x;
	return qpower(x,n/2)*qpower(x,n/2)*(n&1?x:1);
}
int main()
{
	cout<<qpower(1.5,5);
}
