#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	float a[10],pjz=0,s,t;
	int i,k;
	for(i=0;i<10;i++)
	{
		cin>>a[i];
		pjz=(a[0]+a[1]+a[2]+a[3]+a[4]+a[5]+a[6]+a[7]+a[8]+a[9])/10;
		//pjz+=a[i]/10  //k+=a[i],pjz=k/(i+1) //pjz=(pjz*i+a[i])/(i+1)
	}
	s=fabs(a[i]-pjz);
	for(i=1;i<10;i++)
	{
		if(fabs(a[i]-pjz)<s)
		{
			s=fabs(a[i]-pjz);
			t=a[i];
		}
	}
	cout<<t<<endl;
}
