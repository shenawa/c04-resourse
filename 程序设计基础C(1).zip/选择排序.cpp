//ѡ������
#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int* a=new int [n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<n-1;i++)
	{
		int k=i;
		for(int j=i+1;j<n;j++)
		{
			if(a[k]>a[j]) k=j;
		}
		if(a[k]!=a[i])
		{
			int temp=a[i];
			a[i]=a[k];
			a[k]=temp;
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}
	delete [] a;
	a=NULL;
}
