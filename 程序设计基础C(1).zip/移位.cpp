#include <iostream>
#include <cmath>
using namespace std;
int py(char* a,int n)
{
	for(int i=0;i<26;i++)
	{
		if(n>26) n=n%26;
		a[i]='A'+(a[i]-'A'+n)%26;
		cout<<a[i];
	} 
}
int main()
{
	int n;
	cin>>n;
	char a[26];
	for(int i=0;i<26;i++)
	{
		a[i]='A'+i;
	}
	py(a,n);
	return 0;
}
