//����˹���� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a;
	cin>>a;
	if(a==1)
	{
		cout<<"DD\n";
		cout<<"D\n";
		cout<<"D\n";
	 } 
	if(a==2)
	{
		cout<<"DDD\n";
		cout<<"  D\n";
	}
	if(a==3)
	{
		cout<<" D\n";
		cout<<" D\n";
		cout<<"DD\n";
	}
	else if(a==4)
	{
		cout<<"D  \n";
		cout<<"DDD\n";
	}
}

//�۳������ 
#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	double a;
	cin>>a;
	a=a/1000;
	cout<<fixed<<setprecision(2)<<max(a,0.1);
	
}

//�ҳ�����ֵ 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a,b,c,d;
	cin>>a>>b>>c>>d;
	if(a==b||a==c||a==d)
	{
		cout<<a;
	}
	if(b==c||b==d)
	{
		cout<<b;
	}
	if(c==d)
	{
		cout<<c; 
	}
	return 0;
}

//һ�Ų����� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	if((a>=60 and b<60) or (a<60 and b>=60))
	{
		cout<<"1"<<endl;
	}
	else {
		cout<<"0"<<endl;
	}
}



//�����һ����λ�� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a;
	cin>>a;
	int y=a%10;
	int s=a/10%10;
	int b=a/100%10;
	int zm=max(max(y,s),b);
	int zd=min(min(y,s),b);
	int zj=y+s+b-zm-zd;
	cout<<zm*100+zj*10+zd<<endl;
	
}

//��У��� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	double a;
	int b;
	char c;
	cin>>a>>b>>c;
	if(a<=37.2&&b==1&&c=='-')
	{
		cout<<"pass";
	}
	else 
	{
		cout<<"stop";
	}
	
}


//����·� 
#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	if((a%400==0) or (a%4==0 and a%100!=0))
	{
		if(b==1||b==3||b==5||b==7||b==8||b==10||b==12)
		{
			cout<<"31";
		}
		if(b==2)
		{
			cout<<"29";
		}
		if(b==4||b==6||b==9||b==11)
		{
			cout<<"30";
		}
	}
	else
	{
		if(b==1||b==3||b==5||b==7||b==8||b==10||b==12)
		{
			cout<<"31";
		}
		if(b==2)
		{
			cout<<"28";
		}
		if(b==4||b==6||b==9||b==11)
		{
			cout<<"30";
		}
	}
	return 0;
}


