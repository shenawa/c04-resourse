#include <iostream>
#include <cstring>
using namespace std;
const int N=5;
struct course
{
	char Course_Name[20]; //�γ����� 
	float Course_Score;  //�γ̷��� 
};
struct student
{
	char name[20];
	course score[3];	
}; 
void find(student array[],char* cour, int n, char* name, float* score)
{
	int i,j;
	for(j=0;j<3;j++)
	{
		if(strcmp(cour,array[i].score[j].Course_Name)==0) break;
	}
	*score=array[0].score[j].Course_Score;
	strcpy(name,array[0].name);
	for(int i=0;i<n;i++)
	{
		if(array[i].score[j].Course_Score>*score)
		{
			*score=array[i].score[j].Course_Score;
			strcpy(name,array[i].name);
		}
	}
}
int main()
{
	student array[N];
	char coursename[20];
	char name[20];
	float score;
	for(int i=0;i<N;i++)
	{
		cin>>array[i].name;
		for(int j=0;j<3;j++)
			cin>>array[i].score[j].Course_Name>>array[i].score[j].Course_Score;
	}
	cin>>coursename;//����Ҫ���ҿγ̵�����
	find(array,coursename,N,name,&score);
	cout<<name<<" "<< score;
    return 0;
}
