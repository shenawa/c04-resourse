#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int n,t=1;
	cin>>n;
	int a[n+1][n+1];
	for(int i=n;i>=1;i--)
	{
		if((n+i)%2==0)
		{
			for(int j=n;j>=1;j--)
			{
				a[i][j]=t++;
			}
		}
		else
		{
			for(int j=1;j<=n;j++)
			{
				a[i][j]=t++;
			}
		}
	} 
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			
			cout<<setw(3)<<a[i][j];
		}
		cout<<endl;
	}
}
