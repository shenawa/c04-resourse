#include <iostream>
using namespace std;
int gcd(int p,int q)
{
	if(p%q==0)
	{
		return q;
	}
	return gcd(q,p%q);
}
int main()
{
	int m,n;
	cin>>m>>n;
	cout<<"gcd="<<gcd(m,n);
}
