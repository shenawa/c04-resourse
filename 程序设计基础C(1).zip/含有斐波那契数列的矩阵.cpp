#include <iostream>
#include <cmath>
using namespace std;
bool fbn(int s[40][40],int p,int q)
{
	for(int i=1;i<p;i++)
	{
		if(s[i][q]<=s[i-1][q])
		{
			return false;
		}
	}
	for(int i=2;i<p;i++)
	{
		if(s[i][q]!=s[i-1][q]+s[i-2][q])
		{
			return false;
		}
	}
	return true;
}
int main()
{
	int a,b;
	cin>>a>>b;
	int s[40][40];
	for(int i=0;i<a;i++)
	{
	    for(int j=0;j<b;j++)
	    {
	        cin>>s[i][j];
        }
	}  
	int f=-1;
	for(int j=0;j<b;j++)
	{
		if(fbn(s,a,j))
		{
			f=j;
			break;
		}
	}
	for(int i=0;i<a;i++)
	{
		cout<<s[i][f]<<" ";
		
	}
	cout<<endl;
	return 0;
}
