//�ƽ̨
#include <iostream>
using namespace std;
int main()
{
	int a[1001];
	int n,lena=1,lenb=1;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	for(int i=2;i<=n;i++)
	{
		if(a[i]==a[i+1])
		{
			lenb++;
			if(lenb>lena)
			{
				lena=lenb;
			}
		}
		else
		{
			lenb=1;
		}
	}
	cout<<lena<<endl;
	return 0;
} 
