//���ֲ��ң���k�����ֵ�λ�ã� 
#include <bits/stdc++.h>
using namespace std;
int arr[1000005],n,k;
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",arr+i); 
	}
	scanf("%d",&k);
	int left=1,right=n,mid;
	while(left<right)
	{
		mid=(left+right+1)/2;
		if(k<arr[mid])
		{
			right=mid-1;
		}
		else
		{
			left=mid;
		}
	}
	if(arr[left]==k)
	{
		cout<<left;
	}
	else
	{
		cout<<-1;
	}
}


// ���ֲ�����ӽ���Ԫ��
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;i++) scanf("%d",&a[i]);
	scanf("%d",&x)
	while(x--)//for(int i=n;i>0;i--)
	{
		scanf("%d",&s)
		if(s<=a[0])
		{
			printf("%d\n",a[0]);
			continue;
		}
		if(s>=a[n-1])
		{
			printf("%d\n",a[n-1]);
			continue;
		}
		h=n-1;//right
		l=0;//left
		while(l<=h)
		{
			m=(h+1)/2;
			if(s==a[m])
			{
				break;
			}
			else if(s>a[m])
			{
				l=m+1;
			}
			else if(s<a[m])
			{
				h=m-1;
			}
		}
		if(l<=h)
		{
			printf("%d\n",s);
		}
		else if(a[l]-s<s-a[h])
		{
			printf("%d\n",a[l]);
		}
		else
		{
			printf("%d\n",a[h]);
		}
	}
} 
