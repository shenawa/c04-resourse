#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int h,l;
	cin>>h>>l;
	int a[260][260];
	for(int i=0;i<h;i++)
	{
		for(int j=0;j<l;j++)
		{
			cin>>a[i][j];
		}
	}
	for(int i=0;i<h/2;i++)
	{
		for(int j=0;j<l;j++)
		{
			swap(a[i][j],a[h-i-1][j]);
		}
	}
	for(int i=0;i<h;i++)
	{
		for(int j=0;j<l;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<"\n";
	}
}
