#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
int main()
{
	int n;
	cin>>n;
	char a[110][20];
	for(int i=0;i<n;i++) cin>>a[i];
	for(int i=0;i<n-1;i++)
	{
		int k=i;
		for(int j=i+1;j<n;j++)
		{
			if(strcmp(a[k],a[j])>0)
			{
				k=j;
			}
		}
		swap(a[k],a[i]);
	}
	char t[1005]="";
	for(int i=0;i<n;i++)
	{
		strcat(t,a[i]);
	}
	bool flag=1;
	for(int i=1;i<strlen(t);i++)
	{
		if(t[i]<t[i-1])
		{
			flag=0;
			break;
		}
	}
	if(flag==0) cout<<0;
	else cout<<1;
}
