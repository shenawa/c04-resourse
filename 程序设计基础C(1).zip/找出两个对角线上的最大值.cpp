#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[21][21];
	int sum=0;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cin>>a[i][j];
			if((i==j || i+j==n-1) && a[i][j]>sum)
			{
				sum=a[i][j];
			}
		}
	}
	cout<<sum;
}
