#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a;
	char b;
	cin>>a>>b;
	if((a==3 and b=='N') or (a==6 and b=='N'))
	{
		cout<<"Happy"<<endl;
	}
	else
	{
		cout<<"Sad"<<endl;
	}
}

#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a;
	cin>>a;
	if ((a/100)%10==a%10)
	{
		cout<<(a/10)%10<<endl;
	}
	else 
	{
		cout<<(a/100)%10<<endl;
	}
}

#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	double a,b,c,d; 
	cin>>a>>b>>c>>d;
	double ax=max(max(a,b),max(c,d));
	double avg=(a+b+c+d)/4;
	cout<<fixed<<setprecision(3);
	cout<<ax<<endl;
	cout<<avg<<endl;
}

#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a;
	cin>>a;
	if(a>=90)
	{
		cout<<"A"<<endl;
	}
	else if(a>=80)
	{
		cout<<"B"<<endl;
	}
	else if(a>=70)
	{
		cout<<"C"<<endl;
	}
	else if(a>=60)
	{
		cout<<"D"<<endl;
	}
	else
	{
		cout<<"E"<<endl;
	}
}

#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
	int a,b,c,d;
	cin>>a>>b>>c>>d;
	if((a==b and b==c and a!=d) or (a==b and b==d and a!=c) or (a==c and c==d and a!=b) or (b==c and c==d and b!=a))
	{
		cout<<"31"<<endl;
	}
	else 
	{
		cout<<"no"<<endl;
	}
}


#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	double a,b,c;
	cin>>a>>b>>c;
	double d=max(max(a,b),c);
	double e=min(min(a,b),c);
	double f=(a+b+c)-d-e;
	if((a*a+b*b==c*c) or (a*a+c*c==b*b) or (b*b+c*c==a*a))
	{
		cout<<fixed<<setprecision(1);
		cout<<e*f/2<<endl;
	}
	else
	{
		cout<<"No"<<endl;
	}
	
}

#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	int n,b;
	cin>>n;
	b=n%4;
	if(b==0)
	{
		cout<<0<<" "<<0<<" "<<n/4;
	}
	if(b==1)
	{
		cout<<0<<" "<<1<<" "<<n/4-1;
	}
	if(b==2)
	{
		cout<<1<<" "<<0<<" "<<n/4-1;
	}
	if(b==3)
	{
		cout<<1<<" "<<1<<" "<<n/4-2;
	}
}

#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	int y,m,d;
	cin>>y>>m>>d;
	if(y<=0 or y>3000 or m<1 or m>12 or d<1 or d>31)
	{
		cout<<"NO"<<endl;
	}
	else if(m==1 or m==3 or m==5 or m==7 or m==8 or m==10 or m==12)
	{
		cout<<"YES"<<endl;
	}
	else if(m==4 or m==6 or m==9 or m==11)
	{
		if(d<=30)
		{
			cout<<"YES"<<endl;
		}
		else
		{
			cout<<"NO"<<endl;
		}
	}
	else
	{
		if(y%400==0 or y%4==0 and y%100!=0)
		{
			if(d<=29)
			{
				cout<<"YES"<<endl;
			}
			else
			{
				cout<<"NO"<<endl;
			}
		}
		else
		{
			if(d<=28)
			{
				cout<<"YES"<<endl;
			}
			else
			{
				cout<<"NO"<<endl;
			}
		}
	}
}

#include<cstdio> 
#include<iostream>
#include<iomanip>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
    int n,a,b,c,d,e,f,x,y,z,m;
    cin>>n;
    cin>>a>>b;
    cin>>c>>d;
    cin>>e>>f;
    if(n%a==0){
        x=n/a*b;	
    }
    else{
    	x=(n/a+1)*b;
    }
    if(n%c==0){
        y=n/c*d;	
    }
    else{
    	y=(n/c+1)*d;
    }
    if(n%e==0){
        z=n/e*f;	
    }
    else{
    	z=(n/e+1)*f;
    }
    m=min(min(x,y),z);
    cout<<m;
}
