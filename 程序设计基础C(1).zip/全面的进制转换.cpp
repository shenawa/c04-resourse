#include<iostream>
#include<cmath>
#include<iomanip>
#include<cstring>
using namespace std; 
unsigned long long jz(int b,char *a)
{
    unsigned long long ans=0;
	for(int i=0;i<strlen(a);i++){
		if(isdigit(a[i])){
			ans=ans*b+a[i]-'0';
		}
		else{
			ans=ans*b+a[i]-'A'+10;
		}
	}
	return ans;    	
}
int main() 
{
    int n;
	cin>>n;
	for(int i=0;i<n;i++){
		int b;
		char a[115];
		cin>>b>>a;
		cout<<jz(b,a)<<endl;
	}   
}
