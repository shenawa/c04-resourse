#include <iostream>
#include <cstring>
#include <cmath> 
using namespace std;
struct stu
{
	char name[20];
	double score;
};
int main()
{
    stu a[120];
	int n=0;
	double b1,b2,b3,b4,b5;
	char name[20];
	while(cin>>a[n].name>>b1>>b2>>b3>>b4>>b5)
	{
		if(b1+b2+b3+b4+b5<300) continue;
		a[n++].score=(b1+b2+b3+b4+b5)/5;
	}
	for(int i=0;i<n-1;i++)
	{
		int k=i;
		for(int j=i+1;j<n;j++)
		{
			if(a[k].score<a[j].score || fabs(a[k].score-a[j].score)<1e-6 && strcmp(a[k].name ,a[j].name)>0)
			{
				k=j;
			}
		}
		swap(a[i],a[k]);
	}
	for(int i=0;i<n;i++)
	{
		cout<<i+1<<" "<<a[i].name<<endl;
	}
}
