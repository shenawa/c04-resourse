#include <iostream>
#include <cstring>
using namespace std;
bool getWord(char*s1,char*s2)
{
	int cnt[26]={0};
	for(int i=0;i<strlen(s1);++i)
	{
		++cnt[s1[i]-97];
	}
	for(int i=0;i<strlen(s2);++i)
	{
		int t=s2[i]-97;
		--cnt[t];
		if(cnt[t]<0) return false;
	}
	return true;
}
int main()
{
	char s1[100],s2[16];
	while(cin>>s1>>s2)
	{
		if(getWord(s1,s2)) cout<<"Yes\n";
		else cout<<"No\n";
	}
}
