//��Ԫ��ټ�
#include <iostream>
#include <cstdio>
#include <iomanip>
using namespace std;
int main()
{
	int x,y,z;
	for (x=0;x<=100;x++){
		for(y=0;y<=100;y++){
			for(z=0;z<=100;z++){
				if(x+y+z==100 and 3*x+2*y+z/3==100 and z%3==0){
					cout<<x<<" "<<y<<" "<<z<<endl;
				}
			}
		}
	}
}
