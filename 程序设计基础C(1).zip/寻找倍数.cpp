
using namespace std;
bool bs(int*a ,int n)
{
	for(int i=0;i<n;i++)
	{
		bool flag=true;
		for(int j=0;j<n;j++)
		{
			if(a[i]%a[j]!=0)
			{
				flag=false;
				break;
			}
		}
		if(flag)
		{
			return true;
		}
	}
	return false;
}
int main()
{
	int t,k;
	cin>>t;
	while(t>0)
	{
		int n;
		cin>>n;
		int *a=new int [n];
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
		}
		if(bs(a,n))
		{
			cout<<"Yes"<<endl;
		}
		else cout<<"No"<<endl;
		delete [] a;
		t--;
	}
	return 0;
}
