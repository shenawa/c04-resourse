#include <iostream>
#include <cstdio>
#include <iomanip>
#include <algorithm>
using namespace std;
int main()
{
	int h,w;
	cin>>h>>w;
	int a[h*w];
	for(int i=0;i<h*w;i++) scanf("%d",a+i);
	for(int i=0;i<h*w-1;i++)
	{
		int k=i;
		for(int j=i+1;j<h*w;j++)
			if(a[j]<a[k]) k=j;
		swap(a[i],a[k]);
	}
	for(int i=0;i<h;i++)
	{
		for(int j=0;j<w;j++)
			cout<<setw(2)<<a[i*w+j]<<" ";
		cout<<"\n";
	}
}
