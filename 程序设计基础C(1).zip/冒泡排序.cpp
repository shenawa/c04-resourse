//ð������ 
#include <cstdio>
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	int n,x;
	cin>>n;
	int b[100];
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
	}
	cin>>x;
	int sum=0;
	for(int i=0;i<n-sum;i++)
	{
		if(b[i]==x)
		{
			for(int j=i+1;j<n;j++)
			{
				b[j-1]=b[j];
			}
			b[n-1]=x;
			sum++;
			i--;
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<b[i]<<" ";
	}
}


//˫��ð������
#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++) cin>>a[i];
	int left=0,right=n-1;
	while(left<right)
	{
		for(int pos=left;pos<right;pos++)
		{
			if(a[pos]>a[pos+1])
			{
				int tmp=a[pos];
				a[pos]=a[pos+1];
				a[pos+1]=tmp;
			}
		}
		right--;
		for(int pos=right;pos>left;pos--)
		{
			if(a[pos]<a[pos-1])
			{
				int tmp=a[pos];
				a[pos]=a[pos-1];
				a[pos-1]=tmp;
			}
		}
		left++;
	}
	for(int i=0;i<n;i++) cout<<a[i]<<" ";
	cout<<endl;
	return 0;
}
